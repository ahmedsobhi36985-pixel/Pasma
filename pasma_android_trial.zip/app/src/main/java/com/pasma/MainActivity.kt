package com.pasma

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.pasma.databinding.ActivityMainBinding
import org.json.JSONArray
import java.nio.charset.Charset

data class CarEntry(val model: String, val engine_location: String, val chassis_location: String)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val entries = ArrayList<CarEntry>()
    private val display = ArrayList<CarEntry>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.topAppBar)

        loadData()
        val adapter = CarAdapter(display) { entry ->
            showDetails(entry)
        }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.searchInput.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {
                filter(s?.toString() ?: "")
                adapter.notifyDataSetChanged()
            }
            override fun afterTextChanged(p0: Editable?) {}
        })
    }

    private fun loadData(){
        try {
            val json = assets.open("data.json").bufferedReader(Charset.forName("UTF-8")).use { it.readText() }
            val arr = JSONArray(json)
            for(i in 0 until arr.length()){
                val obj = arr.getJSONObject(i)
                val e = CarEntry(
                    obj.getString("model"),
                    obj.getString("engine_location"),
                    obj.getString("chassis_location")
                )
                entries.add(e)
            }
            display.clear()
            display.addAll(entries)
        } catch (e: Exception){
            // ignore
        }
    }

    private fun filter(q: String){
        val s = q.trim().lowercase()
        display.clear()
        if(s.isEmpty()){
            display.addAll(entries)
            return
        }
        for(it in entries){
            if(it.model.lowercase().contains(s)) display.add(it)
        }
    }

    private fun showDetails(entry: CarEntry){
        val msg = "مكان رقم المحرك:\n${entry.engine_location}\n\nمكان رقم الشاسيه:\n${entry.chassis_location}"
        AlertDialog.Builder(this)
            .setTitle(entry.model)
            .setMessage(msg)
            .setPositiveButton("حسناً", null)
            .show()
    }
}

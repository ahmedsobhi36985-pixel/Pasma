package com.pasma

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CarAdapter(private val items: List<CarEntry>, private val onClick: (CarEntry)->Unit) : RecyclerView.Adapter<CarAdapter.VH>() {
    class VH(itemView: View): RecyclerView.ViewHolder(itemView){
        val title: TextView = itemView.findViewById(R.id.title)
        val sub: TextView = itemView.findViewById(R.id.sub)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_car, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val it = items[position]
        holder.title.text = it.model
        holder.sub.text = "عرض أماكن السيريال"
        holder.itemView.setOnClickListener { onClick(it) }
    }

    override fun getItemCount(): Int = items.size
}
